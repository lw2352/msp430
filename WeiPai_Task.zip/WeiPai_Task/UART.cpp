#include "wizepipes.h"
/**********���ݽ���ȫ�ֱ���***********/
extern char rbuffer[MAX_BUFFER];
extern char raddr,IsHaveCommand;
extern char IsReceiveCommand;
/************************************/

/**********GPS���շ���ȫ�ֱ���***********/
extern char gpsrbuf[MAX_BUFFER];
extern char gpstbuf[MAX_BUFFER];
extern char isgpscmdok,gpsaddr,gpsstep;
/************************************/

extern char netstatus;//����״̬,Ĭ�϶Ͽ�
extern char R_delay;
extern Task task;


#pragma vector=USCIAB0RX_VECTOR
__interrupt void USCI0RX_ISR(void)
{ 
  while (!(IFG2&UCA0RXIFG));  
  rbuffer[raddr]=UCA0RXBUF; 
  
  if(IsReceiveCommand==0)
  {
    if(rbuffer[raddr-3]=='O' && rbuffer[raddr-2]=='K' && rbuffer[raddr-1]=='\r' && UCA0RXBUF=='\n'){IsHaveCommand=C_OK;raddr=0;}//OK
    else if(rbuffer[raddr-6]=='r' && rbuffer[raddr-5]=='e' && rbuffer[raddr-4]=='a' && rbuffer[raddr-3]=='d' && rbuffer[raddr-2]=='y' && rbuffer[raddr-1]=='\r' && UCA0RXBUF=='\n'){IsHaveCommand=C_READY;raddr=0;}//ready
    else if(rbuffer[raddr-5]=='F' && rbuffer[raddr-4]=='A' && rbuffer[raddr-3]=='I' && rbuffer[raddr-2]=='L' && rbuffer[raddr-1]=='\r' && UCA0RXBUF=='\n'){IsHaveCommand=C_FAIL;netstatus=0;raddr=0;}//fail
    else if(rbuffer[raddr-6]=='E' && rbuffer[raddr-5]=='R' && rbuffer[raddr-4]=='R' && rbuffer[raddr-3]=='O' && rbuffer[raddr-2]=='R' && rbuffer[raddr-1]=='\r' && UCA0RXBUF=='\n'){IsHaveCommand=C_ERROR;raddr=0;}//error
    else if(rbuffer[raddr-7]=='C' && rbuffer[raddr-6]=='L' && rbuffer[raddr-5]=='O' && rbuffer[raddr-4]=='S' && rbuffer[raddr-3]=='E' && rbuffer[raddr-2]=='D' && rbuffer[raddr-1]=='\r' && UCA0RXBUF=='\n')
      {IsHaveCommand=C_DISCONNECT;raddr=0;netstatus=0; task.ConnectwifiFlag = 1;}//link is lost
    else if(UCA0RXBUF=='>'){IsHaveCommand=D_INPUT;}//>
    else if(rbuffer[raddr-3]=='+' && rbuffer[raddr-2]=='I' && rbuffer[raddr-1]=='P' && UCA0RXBUF=='D')
    {
      IsReceiveCommand=1;            
    }
    else raddr++;
  }
  //���ܵ�ָ������
  if(IsReceiveCommand==1)
  {
    raddr++;
    if(UCA0RXBUF==':')
      raddr=0;  
    if(raddr>2 )
    {
      if(rbuffer[raddr-2]==0x5A && UCA0RXBUF==0x5A)
      { 
        
        R_delay = 6;
        _EINT();//�����ж�
        
        IE2   &= ~UCA0RXIE;                         //�ر�������������
        
        task.dotaskFlag = 1;
      }
    } 
    if(raddr==2)
    {
      if(rbuffer[0]!=0xA5 || rbuffer[1]!=0xA5) 
      {
        IsReceiveCommand=0;
      }
    }
    if(raddr > 50)
      IsReceiveCommand=0;
  }
  if(raddr == MAX_BUFFER) {raddr=0;}
  
}

//����GPSģ��ʱ������жϴ�������
#pragma vector=USCIAB1RX_VECTOR
__interrupt void USCI1RX_ISR(void)
{
  //int i;
  //  unsigned long tmp1=0,tmp2=0;
  
  switch(gpsstep)
  {
  case 0:if(UCA1RXBUF=='$')
  {
    gpsstep=1;
    isgpscmdok=0;
    gpsaddr=0;
    gpsrbuf[gpsaddr++]=UCA1RXBUF;
  }
  else
  {
    gpsstep=0;
    gpsaddr=0;
  }
  break;
  case 1:if(UCA1RXBUF=='G')
  {
    gpsstep=2;
    gpsrbuf[gpsaddr++]=UCA1RXBUF;
  }
  else
  {gpsstep=0;gpsaddr=0;}
  break;
  case 2:if(UCA1RXBUF=='P')
  {
    gpsstep=3;
    gpsrbuf[gpsaddr++]=UCA1RXBUF;
  }
  else
  {gpsstep=0;gpsaddr=0;}
  break;       
  case 3:if(UCA1RXBUF=='G')
  {
    gpsstep=4;
    gpsrbuf[gpsaddr++]=UCA1RXBUF;
  }
  else
  {gpsstep=0;gpsaddr=0;}
  break;
  case 4:if(UCA1RXBUF=='G')
  {
    gpsstep=5;
    gpsrbuf[gpsaddr++]=UCA1RXBUF;
  }
  else
  {gpsstep=0;gpsaddr=0;}
  break; 
  case 5:if(UCA1RXBUF=='A')
  {
    gpsstep=6;
    gpsrbuf[gpsaddr++]=UCA1RXBUF;
  }
  else
  {gpsstep=0;gpsaddr=0;}
  break;
  case 6:
    gpsrbuf[gpsaddr++]= UCA1RXBUF;
    break;
  default:
    gpsstep=0;
    gpsaddr=0;  
  }//end switch
  
  if(gpsaddr >= 43)                                          //������ʱ����Ϣ
  {
    UC1IE &= ~UCA1RXIE;                                      //�ر�GPS����
    
    gpsstep=0;
    gpsaddr=0; 
    
    
    task.parseGPSrbufFlag = 1;
  }

}