
#include "wizepipes.h"

/**********���ݽ���ȫ�ֱ���***********/
extern char rbuffer[MAX_BUFFER];
extern char raddr,IsHaveCommand;
extern char IsReceiveCommand;
/************************************/

/**********GPS���շ���ȫ�ֱ���***********/
extern char gpsrbuf[MAX_BUFFER];
extern char gpstbuf[MAX_BUFFER];
extern char isgpscmdok,gpsaddr,gpsstep;
/************************************/
/**********ATָ������***********/
extern char ATMSG[MAX_BUFFER];
/******************************/
/********�����뿪��ʱ��*************/
extern WAk_CLO wak_clo;
/**********************************/
extern  char temp[MAX_BUFFER];
extern PPS PPS1;
extern char netstatus;//����״̬,Ĭ�϶Ͽ�

extern char ADdata[8];
extern unsigned char test_data;
extern unsigned long flash_addr;
extern Lng_Lat Lngtude_Lattude;

extern unsigned char Iscontinue;
extern unsigned char counter;
extern unsigned char Isover;
extern unsigned char cap_step;
extern unsigned char IsEarase;
extern unsigned long time,time1; 
extern unsigned char time_hour;
extern unsigned char second;
extern unsigned short msecond ;
extern char GPS_stauts;

//����ѡ��ʱʱ���ı���
extern unsigned char WDT_Func;
extern unsigned long timeout;
Off_Set off_set;

extern WDATA wd1;
extern CDATA cd1;
extern TDATA td1;

/****���뼶�ӳٺ���**********/
/*
Input:     �ӳٶ೤ʱ�䣨ms��
Output:    �� 
*/
void Delay_ms(unsigned int ms){
  unsigned int i;
 for(;ms>0;ms--)
   for(i=0;i<0x7e7;i++)_NOP();
}
/*********************/


unsigned char Gps_send(char sbuf[],unsigned char slen)
{
  for(int counter_tx=0;counter_tx<slen;counter_tx++)
  {
    while (!(UC1IFG&UCA1TXIFG));  
    UCA1TXBUF=sbuf[counter_tx];   
  }
   return 0;
}



/*****************************
*name     : PPS_choose
*function : ������ѡ1pps�Ĺ���
*input    : ѡ������һ�ֹ���
*ouput    : 1�ɹ���0ʧ��
*****************************/
char PPS_choose(char step)
{
  _EINT();
  if( step > 10 && step < 14){
    
  PPS1.PPS_step = step;
  
  P2DIR &= ~0x80;
  P2IE |= 0x80;             // P2.7 interrupt enabled
  P2IES &= ~0x80;           // P2.7 lo/Hi edge
  P2IFG &= ~0x80;           // P2.7 IFG cleared
  
  return 1;
  }
  else return 0;
}

void sendheartbeat()
{
  IsHaveCommand=0;
  raddr=0; 
  strcpy(ATMSG,"AT+CIPSEND=12\r\n");//��������ָʾ
  senddata(ATMSG,strlen(ATMSG));
  Delay_ms(100);
    ATMSG[0]=0xA5;
    ATMSG[1]=0xA5;    
    ATMSG[2]=0xFF;
    ATMSG[3]=cd1.ID[0];
    ATMSG[4]=cd1.ID[1];
    ATMSG[5]=cd1.ID[2];
    ATMSG[6]=cd1.ID[3];
    ATMSG[7]=0x01;
    ATMSG[8]=PPS1.PPS1;
    ATMSG[9]=0xFF;  
    ATMSG[10]=0x5A;
    ATMSG[11]=0x5A;        
    senddata(ATMSG,12);
    Delay_ms(100);
}


unsigned char senddata(char sbuf[],unsigned char slen)
{
  for(int counter_tx=0;counter_tx<slen;counter_tx++)
  {
    while (!(IFG2&UCA0TXIFG));  
    UCA0TXBUF=sbuf[counter_tx];   
  }
   return 0;
}


void dmGPS()
{
 unsigned long j;
 for(j=0x1FFFF;j>0;j--)_NOP();
}
void Gps_MSG()
{
  UC1IE |= UCA1TXIE;
  //���÷�������׼��
  gpstbuf[0]=0xB5;
  gpstbuf[1]=0x62;
  gpstbuf[2]=0x06;
  gpstbuf[3]=0x00;
  gpstbuf[4]=0x14;
  gpstbuf[5]=0x00;
  gpstbuf[6]=0x01;
  gpstbuf[7]=0x00;
  gpstbuf[8]=0x00;
  gpstbuf[9]=0x00;
  gpstbuf[10]=0xD0;
  gpstbuf[11]=0x08;
  gpstbuf[12]=0x00;
  gpstbuf[13]=0x00;
  gpstbuf[14]=0x00;
  gpstbuf[15]=0x96;
  gpstbuf[16]=0x00;
  gpstbuf[17]=0x00;
  gpstbuf[18]=0x07;
  gpstbuf[19]=0x00;
  gpstbuf[20]=0x03;
  gpstbuf[21]=0x00;
  gpstbuf[22]=0x00;
  gpstbuf[23]=0x00;
  gpstbuf[24]=0x00;
  gpstbuf[25]=0x00;
  gpstbuf[26]=0x93;
  gpstbuf[27]=0x90;
  Gps_send(gpstbuf,28);
  dmGPS();

  gpstbuf[0]=0xB5;
  gpstbuf[1]=0x62;
  gpstbuf[2]=0x06;
  gpstbuf[3]=0x01;
  gpstbuf[4]=0x08;
  gpstbuf[5]=0x00;
  gpstbuf[6]=0xF0;
  gpstbuf[7]=0x04;
  gpstbuf[8]=0x00;
  gpstbuf[9]=0x00;
  gpstbuf[10]=0x00;
  gpstbuf[11]=0x00;
  gpstbuf[12]=0x00;
  gpstbuf[13]=0x01;
  gpstbuf[14]=0x04;
  gpstbuf[15]=0x40;
  Gps_send(gpstbuf,16);
  dmGPS();

  gpstbuf[7]=0x02;
  gpstbuf[14]=0x02;
  gpstbuf[15]=0x32;
  Gps_send(gpstbuf,16);
  dmGPS();

  gpstbuf[7]=0x03;
  gpstbuf[14]=0x03;
  gpstbuf[15]=0x39;
  Gps_send(gpstbuf,16);
  dmGPS();

  gpstbuf[7]=0x01;
  gpstbuf[14]=0x01;
  gpstbuf[15]=0x2B;
  Gps_send(gpstbuf,16);
  dmGPS();

  gpstbuf[7]=0x05;
  gpstbuf[14]=0x05;
  gpstbuf[15]=0x47;
  Gps_send(gpstbuf,16);
  dmGPS();

  gpstbuf[7]=0x00;
  gpstbuf[9]=0x01;
  gpstbuf[14]=0x01;
  gpstbuf[15]=0x29;
  Gps_send(gpstbuf,16);
  dmGPS();
 
  gpstbuf[0]=0xB5;
  gpstbuf[1]=0x62;
  gpstbuf[2]=0x06;
  gpstbuf[3]=0x07;
  gpstbuf[4]=0x14;
  gpstbuf[5]=0x00;
  gpstbuf[6]=0x40;
  gpstbuf[7]=0x42;
  gpstbuf[8]=0x0F;
  gpstbuf[9]=0x00;
  gpstbuf[10]=0xA0;
  gpstbuf[11]=0x86;
  gpstbuf[12]=0x01;
  gpstbuf[13]=0x00;
  gpstbuf[14]=0x01;
  gpstbuf[15]=0x00;
  gpstbuf[16]=0x00;
  gpstbuf[17]=0x00;
  gpstbuf[18]=0x34;
  gpstbuf[19]=0x03;
  gpstbuf[20]=0x00;
  gpstbuf[21]=0x00;
  gpstbuf[22]=0x00;
  gpstbuf[23]=0x00;
  gpstbuf[24]=0x00;
  gpstbuf[25]=0x00;
  gpstbuf[26]=0x11;
  gpstbuf[27]=0x86;
  Gps_send(gpstbuf,28);
  dmGPS();
  
  gpstbuf[0]=0xB5;
  gpstbuf[1]=0x62;
  gpstbuf[2]=0x06;
  gpstbuf[3]=0x31;
  gpstbuf[4]=0x20;
  gpstbuf[5]=0x00;
  gpstbuf[6]=0x00;
  gpstbuf[7]=0x01;
  gpstbuf[8]=0x00;
  gpstbuf[9]=0x00;
  gpstbuf[10]=0x00;
  gpstbuf[11]=0x00;
  gpstbuf[12]=0x00;
  gpstbuf[13]=0x00;
  gpstbuf[14]=0x01;
  gpstbuf[15]=0x00;
  gpstbuf[16]=0x00;
  gpstbuf[17]=0x00;
  gpstbuf[18]=0x01;
  gpstbuf[19]=0x00;
  gpstbuf[20]=0x00;
  gpstbuf[21]=0x00;
  gpstbuf[22]=0x32;
  gpstbuf[23]=0x00;
  gpstbuf[24]=0x00;
  gpstbuf[25]=0x00;
  gpstbuf[26]=0xE8;
  gpstbuf[27]=0x03;
  gpstbuf[28]=0x00;
  gpstbuf[29]=0x00;
  gpstbuf[30]=0x00;
  gpstbuf[31]=0x00;
  gpstbuf[32]=0x00;
  gpstbuf[33]=0x00;
  gpstbuf[34]=0x7F;
  gpstbuf[35]=0x08;
  gpstbuf[36]=0x00;
  gpstbuf[37]=0x00;
  gpstbuf[38]=0xFE;
  gpstbuf[39]=0x4B;
  Gps_send(gpstbuf,40);//TP5, 1Hz, UTC,
  dmGPS();

  UC1IE &= ~UCA1TXIE;
}




