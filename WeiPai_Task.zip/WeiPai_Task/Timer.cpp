#include "wizepipes.h"
#define DATA_QUANTITY (600000)
/**********ATָ������***********/
extern char ATMSG[MAX_BUFFER];
/******************************/
extern char ADdata[8];
extern unsigned char cap_step;
/********�����뿪��ʱ��*************/
extern WAk_CLO wak_clo;
extern unsigned long time;
extern unsigned long flash_addr;
extern PPS PPS1;
extern char GPS_stauts;
extern CDATA cd1;
extern char R_delay;;
extern Task task;


// Timer A0 interrupt service routine
#pragma vector=TIMERA0_VECTOR
__interrupt void Timer_A (void)
{
  switch(cap_step)
  {
  case 0:
    if(time)
      time--;
    if(time ==0)
    {
      //CCTL0 &= ~CCIE;                  
      //TACTL = MC_0; 
      cap_step = 1;
      UC1IE |= UCA1RXIE;                          //����GPS���ڻ�ȡʱ�� 
    }
    break;
  case 2:
    if(time)
      time--;  
    
    if( wak_clo.close )
    {                           //�ر�ʱ����ʱ
      wak_clo.close--;
      if( wak_clo.close == 0)
      {
        PPS1.PPS1 = 0;
        PPS_choose(PPS_1);
        
        P2OUT |= 0x40;                              //����wifi��GPS���� P2.6
        P3OUT |= 0x01;                              //��������������ģ��P3.0
        
        //LPM3_EXIT;  //exit LPM3
      }
    }
    else if( wak_clo.open )
    {                      //����ʱ����ʱ
      wak_clo.open--;
    }
    
    if(R_delay)                                  
      R_delay--;
    
    if( (wak_clo.open == 0)&&(R_delay == 1) )
    {
      cap_step = 1;
      UC1IE |= UCA1RXIE;
    }
    else if( (wak_clo.open == 0) && (R_delay == 0) && (time > 40) )
    {
      P2OUT &= ~0x40;                              //�ر�wifi��GPS����  P2.6
      P3OUT &= ~0x01;                              //�رմ���������ģ�� P3.0
      
      wak_clo.close = wak_clo.T_Close;
      wak_clo.open = wak_clo.T_Open;
      
      //task = 4;//enter LPM3
    }
    
    _EINT();                                     //����ȫ���ж�
    if( time==0 )
    {
      //P2OUT |= 0x40;                              //����wifi��GPS���� P2.6
      //P3OUT |= 0x01;                              //��������������ģ��P3.0 
      
      CCTL0 &= ~CCIE;                           //�رն�ʱ��A                        
      TACTL = MC_0;
      
      //���ò�������
      ADC12CTL0 |= ADC12ON+SHT0_7+REFON+REF2_5V;     // Turn on ADC12, set sampling time
      ADC12CTL1 |= SHP+CONSEQ_0;                     // Use sampling timer, set mode  
      ADC12MCTL0 = SREF_1+INCH_1;                    // Vr+ = VREF+
  
      ADC12IE = 0x01;                               // Enable ADC12IFG.0
      ADC12CTL0 |= ENC;                             // Enable conversions
      
      /**********���flashоƬ�Ƿ񱻲���***********/
      for(char i=0;i<8;i++)
        ADdata[i]=MX29LV320t_Flash_Read(i);
      if(ADdata[0]==0xFF&&ADdata[1]==0xFF&&ADdata[2]==0xFF&&ADdata[3]==0xFF&&ADdata[4]==0xFF&&ADdata[5]==0xFF&&ADdata[6]==0xFF&&ADdata[7]==0xFF)_NOP();
      else
      {
        //MX29LV320t_Cmd_Reset();                        //flash��оƬ��λ
        //MX29LV320t_Cmd_Erase_Chip();                   //��flash����оƬ����
        task.EraseFlashFlag = 1;
      }
      /********************************************/ 
      
      cap_step = 3;     
      IE2 &= ~UCA0RXIE;                         //������ͨѶ��׼���ɼ�����           
      UC1IE |= UCA1RXIE;                             // //����GPS����,��ȡ�����㵹��ʱ������
    }
    else if( (wak_clo.close == 0 && wak_clo.open != 0) || (time<=40))
    {
      
      task.checkWifiFlag = 1;
      
    }
    
    if( time == 40 )
    {
      
      CCTL0 &= ~CCIE;                             //�رն�ʱ��     
      TACTL  =  MC_0; 
      
      //P2OUT |= 0x40;                              //����wifi��GPS���� P2.6
      //P3OUT |= 0x01;                              //��������������ģ��P3.0 
      
      UC1IE |= UCA1RXIE;                          //����GPS����ȡ��ǰʱ��
      cap_step  = 1;
    } 
    break;

  default:
    //�ر�ʱ�䶨ʱ��Timer A0
    CCTL0 &= ~CCIE;                            // CCR0 interrupt disabled
    //�رռ���
    TACTL = MC_0; 
  }//end switch
  
}//end timeA 


// Timer B0 interrupt service routine
#pragma vector=TIMERB0_VECTOR
__interrupt void Timer_B (void)
{
  ADC12CTL0 |= ADC12SC;                         // Start conversion 
}

#pragma vector=ADC12_VECTOR
__interrupt void ADC12ISR (void)
{
  
  if(flash_addr<DATA_QUANTITY)   
  {
    MX29LV320t_Flash_Write(flash_addr,(ADC12MEM0>>8)&0x0F);     
    flash_addr += 1;   
    MX29LV320t_Flash_Write(flash_addr,ADC12MEM0&0xFF);  
    flash_addr += 1; 
  }
  else
  {
    //�رղ�����ʱ��Timer B0
    TBCCTL0 &= ~CCIE;                           // CCR0 interrupt disabled
    TBCTL = MC_0;   
    
    ADC12IE ^= 0x01;                           // Enable ADC12IFG.0
    ADC12CTL0 &= ~ADC12SC;                     // stop conversion
    ADC12CTL0 &= ~ENC;                         // disable conversions
    ADC12CTL0 &= ~ADC12ON;
    
    _EINT();//�����ж�
    strcpy(ATMSG,"AT+CIPSEND=13\r\n");          //��������ָʾ
    senddata(ATMSG,strlen(ATMSG));
    
    Delay_ms(100);                             //�ӳ�100ms;
    
    ATMSG[0]=0xA5;     
    ATMSG[1]=0xA5;     
    ATMSG[2]=0x22;     
    ATMSG[3]=cd1.ID[0];     
    ATMSG[4]=cd1.ID[1]; 
    ATMSG[5]=cd1.ID[2];     
    ATMSG[6]=cd1.ID[3];     
    ATMSG[7]=0x00;     
    ATMSG[8]=0x01;     
    ATMSG[9]=0x55;     
    ATMSG[10]=0xFF;     
    ATMSG[11]=0x5A;     
    ATMSG[12]=0x5A;     
    senddata(ATMSG,13);
    
    Delay_ms(100);                             //�ӳ�100ms
    
    wak_clo.close = 0;                        //���ò�����ɺ�Ԥ��ʱ��Ϊwak_clo.open/2 =10minute
    wak_clo.open  = 60;
    
    GPS_stauts =  GPS_Date;
    cap_step = 1; 
    //�ٴδ�GPS���գ�У׼����ʱ��ʱ��
    UC1IE |= UCA1RXIE;                        //Enable USCI_A1 RX interrupt  
    
    //LPM1_EXIT; //exit LPM1
  } 
}