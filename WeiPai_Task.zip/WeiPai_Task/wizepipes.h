#include "msp430x24x.h"
#include "stdlib.h"
#include "string.h"

#define CPU_CLK 16000000 //CPU����ʱ��Ϊ16M

#define C_OK            1
#define C_ERROR         2
#define C_FAIL          3
#define C_DISCONNECT    4
#define D_IPD           5
#define D_INPUT         6
#define C_UNLINK        7
#define C_RCOMMAND      8
#define C_WRONG         9
#define C_READY         10
#define PPS_1           11
#define PPS_2           12
#define PPS_3           13
#define GPS_Time        14
#define GPS_Date        15
#define MAX_BUFFER 96

typedef struct wifidata
{
  char IsWifidefault;//�Ƿ�Ĭ��wifi�˺������½
  char IsWifiConnected;
  char Baute;
  char Type;//  ͨѶЭ��
  char Ap_name[15];
  char AP_password[12];
  char ServerIP[16];
  char Serverport[8];
} WDATA;


/****�豸�ر������ѽṹ��***/
typedef struct Wake_close
{
  unsigned int T_Close;
  unsigned int T_Open;
  
  unsigned int close;
  unsigned int open;
}WAk_CLO;

/****1pps����ѡ��ṹ��***/
typedef struct PPS1
{ 
  char PPS_step;
  char PPS1;
}PPS;

typedef struct configdata
{
  short hour;
  short minute;
  char ID[5];
} CDATA;

typedef struct capturedata
{
  char hour;
  char minute;
  char seconds;
  char ms;
} TDATA;

typedef struct offset
{
  char offset;
} Off_Set;

typedef struct LNG_LAT
{
  char Lng[12];
  char Lat[12];
  
} Lng_Lat;

typedef struct taskFlag
{
  int sendheartbeatFlag;
  int ConnectwifiFlag;
  int dotaskFlag;
  int parseGPSrbufFlag;
  int checkWifiFlag;
  int EraseFlashFlag;
} Task;


void Delay_ms(unsigned int ms);
void InitialSystem();
void ReadConfig();
unsigned long ReadGPSInfo();
char Connectwifi();  
void dotask();
void docapture();
void sendheartbeat();
unsigned char senddata(char sbuf[],unsigned char slen);
void MX29LV320t_Cmd_Reset(void);
void MX29LV320t_Cmd_Erase_Chip();  
void MX29LV320t_Flash_Write(unsigned long vaddress, unsigned char vdata);
unsigned char MX29LV320t_Flash_Read(unsigned long vaddress);
void MX29LV320t_Command_Write(unsigned long vaddress, unsigned char vdata);
void write_SegB();
void write_SegC();
void write_SegD();
void GetMessage();
void OutTimer();
char PPS_choose(char step);
unsigned char Gps_send(char sbuf[],unsigned char slen);
void Gps_MSG();
void parseGPSrbuf();
char CheckWifi();

