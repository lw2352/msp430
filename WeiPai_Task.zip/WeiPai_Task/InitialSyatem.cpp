#include "wizepipes.h"

extern WDATA wd1;
extern CDATA cd1;
extern TDATA td1;
extern char GPS_stauts;
/********�����뿪��ʱ��*************/
extern WAk_CLO wak_clo;

void InitialSystem()
{
 // unsigned long i;

  // Stop watchdog timer to prevent time out reset
  WDTCTL = WDTPW + WDTHOLD; 
 
  //��Ϊʹ��XT2
  BCSCTL1 &= ~XT2OFF;                       // Activate XT2 high freq xtal
  BCSCTL1 &= ~XTS;                          //LFXT1��Ƶ��ģʽ(32.768K)
  BCSCTL1 |=DIVA_3;                          //ACLK=32.768k/8=4096
  BCSCTL3 |= XT2S_2;                        // ʹ��3-16M�ⲿ����
  BCSCTL3 |= XCAP_2;                        // XIN/XOUT Cap : 10 pF 
  BCSCTL3 |= LFXT1S_0;
  
  do
  {
    IFG1 &= ~OFIFG;                         // Clear OSCFault flag
    for (int i = 0xFF; i > 0; i--);             // Time for flag to set
  }
  while (IFG1 & OFIFG);                     // OSCFault flag still set?

  BCSCTL2 |= SELM_2;                        // MCLK = XT2 HF XTAL (safe)
  BCSCTL2 |= SELS;                          
  BCSCTL2 |= DIVS_1;                        // SCLK = XT2/2  
  //�޸�ʱ�ӽ���
  
  FCTL2 = FWKEY + FSSEL1 + FN1;             // MCLK/3 for Flash Timing Generator
  
  //��ʼ���˿�
  P1DIR = 0xFF;                             // Flash 8λ������
 // P1OUT |= 0xFF;                             
  
  
  P2DIR |= 0xFF;                             // A16-21 A-1 P2.6 1PPS
  P2DIR &= ~0x80;                             // A16-21 A-1 P2.7 1PPS
  P2OUT |= 0x40;                             // All P2.x reset
  //P2OUT &= ~0x40;

  
  
  P3SEL = 0xF0;                            // P3.3,2 USCI_B0 option select
                                            // P3.4,5 = USCI_A0 TXD/RXD
                                            //P3.6,7 = USCI_A1 TXD/RXD
 //P3.0 = CFG_GPS0 output P3.1 = extint0_GPS input P3.2 NC  output P3.3 WIFI_CH_PD output
  P3DIR |=0x0F;
  //P3DIR &= ~0x02; //P3.2 = DOUT input
  P3OUT |= 0x0D;
  //P3OUT &= ~0x01; 

  
  P4DIR = 0xFF;                             // A0-A7
 // P4OUT = 0x00;                                // All P4.x reset
  
  P5DIR = 0xFF;                             // A8-A15
 // P5OUT = 0x00;                                // All P5.x reset

  //P6SEL  |=  0x08;                             // P3.0,1 = AD input
  P6SEL  |=  0x0A;
  //P6DIR  |=  0xF7;                             // P6.0~1 inputs,P6.2~7 outputs
  P6DIR  |=  0xF5;
  P6OUT  |=  0x05;


  
  //UART0 config to wifi
 /* UCA0CTL1 |= UCSSEL_2;                     // CLK = SMCLK
  UCA0BR0 = 0x41;                           // 8MHz/115200 = 69
  UCA0BR1 = 0x03;                           //
  UCA0MCTL = UCBRS_2 + UCBRF_0;      // Modulation UCBRSx = 4 UCBRFx=0  
  UCA0CTL1 &= ~UCSWRST;                     // **Initialize USCI state machine**
  IE2 &= ~UCA0RXIE; */

  //UART0 config to wifi
  UCA0CTL1 |= UCSSEL_2;                     // CLK = SMCLK
  UCA0BR0 = 69;                           // 8MHz/115200 = 69
  UCA0BR1 = 0x00;                           //
  UCA0MCTL = UCBRS_4 + UCBRF_0;      // Modulation UCBRSx = 4 UCBRFx=0  
  UCA0CTL1 &= ~UCSWRST;                     // **Initialize USCI state machine**
  IE2 &= ~UCA0RXIE;

//    //UART1 config to GPS test
//  UCA1CTL1 |= UCSSEL_2;                      // CLK = SMCLK                            
//  UCA1BR0 = 0x41;                            // 8MHz/9600 = 0x341
//  UCA1BR1 = 0x03;                            // Modulation UCBRSx = 0                                               
//  UCA1MCTL = UCBRS_2 + UCBRF_0;              // **Initialize USCI state machine** 
//  UCA1CTL1 &= ~UCSWRST;
//  UC1IE &= ~UCA1RXIE;
  
  
  //UART1 config to GPS
  UCA1CTL1 |= UCSSEL_2;                        // CLK = SMCLK
  UCA1BR0 = 0xD0;                              // 8MHz/38400 = 208
  UCA1BR1 = 0x00;                              // 
  UCA1MCTL = UCBRS_3 + UCBRF_0;             // Modulation UCBRSx = 0
  UCA1CTL1 &= ~UCSWRST;                     // **Initialize USCI state machine**   
  UC1IE &= ~UCA1RXIE;

  Gps_MSG();
  
  //reset external flash
  MX29LV320t_Cmd_Reset();
 
}
void ReadConfig()
{
  // char i;
  
  char *addr=(char *)0x1040;
    
    /*for(i=0;i<15;i++)wd1.Ap_name[i]     =*addr++;
    for(i=0;i<12;i++)wd1.AP_password[i] =*addr++;
    for(i=0;i<16;i++)wd1.ServerIP[i]    =*addr++; 
    for(i=0;i<8;i++) wd1.Serverport[i]  =*addr++;
    
    strcpy(wd1.Ap_name,"ABC");
    strcpy(wd1.AP_password,"VP2A4008");
    //strcpy(wd1.ServerIP,"120.25.229.254");
    strcpy(wd1.ServerIP,"196.168.23.1");
    strcpy(wd1.Serverport,"8081");*/
  
  addr = (char *)0x1080;               // Initialize Flash pointer
  
  if( *addr != 0xff){
    
  td1.hour        = *addr++;                  //������ʱ��д��ṹ����
  td1.minute      = *addr++;
  td1.seconds     = *addr++;
  td1.ms          = *addr++;
  } else{
    
    td1.hour      = 23;
    td1.minute    = 07;
  }
    
  cd1.ID[0]       = 0x00;
  cd1.ID[1]       = 0x00;
  cd1.ID[2]       = 0x00;
  cd1.ID[3]       = 0x03;
  
  addr = (char *)0x1000;
/* 
  if( *addr != 0xff){
    
  wak_clo.T_Open   = (*addr)<<4;
  addr++;
  wak_clo.T_Open  +=  *addr++;
  
  wak_clo.T_Close  = (*addr)<<4;
  addr++;
  wak_clo.T_Close +=  *addr++;
  
  wak_clo.open     =   wak_clo.T_Open;
  wak_clo.close    =   wak_clo.T_Close;
  } else{
    
   wak_clo.T_Open  = 20;                   //20/2 = 10(����)
   wak_clo.T_Close = 600;                  //600/2 = 300(����)
   wak_clo.open    = 120;
   wak_clo.close   = 0;
  }
 */
   wak_clo.T_Open  = 120;                   //20/2 = 10(����)
   wak_clo.T_Close = 10;                  //600/2 = 300(����)
   wak_clo.open    = 120;
   wak_clo.close   = 0;
   
  GPS_stauts = GPS_Time;                   //��ȡGPSʱ������
}
