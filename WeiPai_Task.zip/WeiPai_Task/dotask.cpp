#include "wizepipes.h"
extern char IsReceiveCommand;
extern char raddr,IsHaveCommand;
extern char rbuffer[MAX_BUFFER];
extern char ATMSG[MAX_BUFFER];
extern  char temp[MAX_BUFFER];

extern WDATA wd1;
extern CDATA cd1;
extern TDATA td1;
extern WAk_CLO wak_clo;
extern Off_Set off_set;

extern unsigned long flash_addr;
extern Lng_Lat Lngtude_Lattude;
extern char ADdata[8];
extern unsigned char cap_step;

void dotask()
{
   unsigned int k=0;
   unsigned char j=0;
   unsigned long sum;
   IsReceiveCommand=0;
   
   //for(char i=0;i<raddr;i++) temp[i]=rbuffer[i];    
   for(char i=0;rbuffer[i-1]!=0x5A;i++)
     temp[i]=rbuffer[i];    
   switch(temp[2]) //�������     
   {
   case 0x22:
    strcpy(ATMSG,"AT+CIPSEND=13\r\n");//��������ָʾ
    senddata(ATMSG,strlen(ATMSG));
    
    Delay_ms(100);                             //�ӳ�100ms;
    
    ATMSG[0]=0xA5;     
    ATMSG[1]=0xA5;     
    ATMSG[2]=0x22;     
    ATMSG[3]=cd1.ID[0];     
    ATMSG[4]=cd1.ID[1]; 
    ATMSG[5]=cd1.ID[2];     
    ATMSG[6]=cd1.ID[3];     
    ATMSG[7]=0x00;     
    ATMSG[8]=0x01;     
    ATMSG[9]=0xAA;     
    ATMSG[10]=0xFF;     
    ATMSG[11]=0x5A;     
    ATMSG[12]=0x5A;     
    senddata(ATMSG,13); 
    Delay_ms(100);                             //�ӳ�100ms
    
    MX29LV320t_Cmd_Reset();                        //flash��оƬ��λ
    MX29LV320t_Cmd_Erase_Chip();               //��flash����оƬ����
    
    TBCCTL0 = CCIE;                           // CCR0 interrupt enabled
    TBCCR0 = 199;
    TBCTL = TBSSEL_2 + MC_1 + ID_3;           // SMCLK/8 = 1MHz, upmode
    flash_addr = 0x0;
     break;
     
   case 0x23:
 
       flash_addr = 0;
       sum = (temp[13]<<8) + temp[14];
       //��003A�滻��030A,013A�滻Ϊ130A��023A�滻Ϊ230A
       if(temp[11]==0x03&&temp[12]==0x0A)
       {
       temp[11]=0x00;
       temp[12]=0x3A;
       }
       if(temp[11]==0x13&&temp[12]==0x0A)
       {
       temp[11]=0x01;
       temp[12]=0x3A;
       }
       if(temp[11]==0x23&&temp[12]==0x0A)
       {
       temp[11]=0x02;
       temp[12]=0x3A;
       }
       
       for(int i=0;i<(temp[11]<<8)+temp[12];i++)
       flash_addr+=sum;  
       if(sum==0)
         flash_addr = 0;
       if(flash_addr%2==0)
       {
         if(((temp[13]<<8)+temp[14])>2046);
         else
         {
         k=(temp[13]<<8)+temp[14]+8;

        while(k>0)
         {
           ATMSG[j]=k%10;
           k=k/10;
           j++;        
         }
        ATMSG[j]='\0';
        while(j>0)
        {
          j--;         
          ADdata[k]=ATMSG[j]+48;
          k++;
        }
        ADdata[k]='\r';
        ADdata[k+1]='\n';
        ADdata[k+2]='\0';
        k=(temp[13]<<8)+temp[14];
        
        Delay_ms(100);
        
        IsHaveCommand=0;
        raddr=0;
        strcpy(ATMSG,"AT+CIPSEND=");//��������ָʾ 
        strcat(ATMSG, ADdata);
        senddata(ATMSG,strlen(ATMSG)); 
        Delay_ms(200);
            while (!(IFG2&UCA0TXIFG));
              UCA0TXBUF=0xA5;
            while (!(IFG2&UCA0TXIFG));
              UCA0TXBUF=0xA5;
            while (!(IFG2&UCA0TXIFG));
              UCA0TXBUF=0xAA;
         for(char sum = 0;sum < 4;sum++){  
            while (!(IFG2&UCA0TXIFG));
              UCA0TXBUF=cd1.ID[sum];
              } 
            for(int i=0;i<k;i++)
            {
              while (!(IFG2&UCA0TXIFG));  
              UCA0TXBUF=MX29LV320t_Flash_Read(flash_addr);
              flash_addr++;
            }
            while (!(IFG2&UCA0TXIFG));
            UCA0TXBUF=0x55;
         }          
       }
       
       CCTL0 |= CCIE;                        // CCR0 interrupt enabled
       CCR0 = 0x3BFE;
       TACTL = TASSEL_1 + MC_1 + ID_3;       // ACLK/8=512Hz, upmode 
       
       IE2 |= UCA0RXIE;                      //���������������� 
      break;
      
   case 0x24:        
     wak_clo.close  = temp[9]<<4;          //�޸ĵ�ǰ�رռ���ʱ��
     wak_clo.close += temp[10];
     
     IsHaveCommand=0;
     raddr=0; 
     strcpy(ATMSG,"AT+CIPSEND=14\r\n");//��������ָʾ
     senddata(ATMSG,strlen(ATMSG));
     
     //�ӳ�100ms
     Delay_ms(100);

      ATMSG[0]=0xA5;
      ATMSG[1]=0xA5;    
      ATMSG[2]=0x24;    
      ATMSG[3]=cd1.ID[0];     
      ATMSG[4]=cd1.ID[1]; 
      ATMSG[5]=cd1.ID[2];     
      ATMSG[6]=cd1.ID[3];     
      ATMSG[7]=0x00;     
      ATMSG[8]=0x02;     
      ATMSG[9]=0x55;     
      ATMSG[10]=0x55;     
      ATMSG[11]=0xFF;
      ATMSG[12]=0x5A;
      ATMSG[13]=0x5A;
      senddata(ATMSG,14);
      //�ӳ�100ms
      Delay_ms(100);
      
      CCTL0 |= CCIE;                       // CCR0 interrupt enabled
      CCR0 = 0x3BFE;
      TACTL = TASSEL_1 + MC_1 + ID_3;      // ACLK/8=512Hz, upmode 
       
      IE2 |= UCA0RXIE;                     //���������������� 
      break;
       
   case 0x25:
     if(temp[7]==0x0)
     {
       IsHaveCommand=0;
       raddr=0; 
       strcpy(ATMSG,"AT+CIPSEND=16\r\n");//��������ָʾ
       senddata(ATMSG,strlen(ATMSG));
       //�ӳ�100ms
       Delay_ms(100);

      ATMSG[0]=0xA5;
      ATMSG[1]=0xA5;    
      ATMSG[2]=0x25;    
      ATMSG[3]=cd1.ID[0];     
      ATMSG[4]=cd1.ID[1]; 
      ATMSG[5]=cd1.ID[2];     
      ATMSG[6]=cd1.ID[3];     
      ATMSG[7]=0x00;     
      ATMSG[8]=0x04;     
      ATMSG[9]=td1.hour;     
      ATMSG[10]=td1.minute;     
      ATMSG[11]=td1.seconds;     
      ATMSG[12]=td1.ms;
      ATMSG[13]=0xFF;
      ATMSG[14]=0x5A;
      ATMSG[15]=0x5A;
      senddata(ATMSG,16);
      //�ӳ�100ms
      Delay_ms(100);
      
      CCTL0 |= CCIE;                       // CCR0 interrupt enabled
      CCR0 = 0x3BFE;
      TACTL = TASSEL_1 + MC_1 + ID_3;      // ACLK/8=512Hz, upmode 
       
      IE2 |= UCA0RXIE;                     //���������������� 
     }
     else
     {
      if(0<temp[9]&&temp[9]<24&&0<temp[10]&&temp[10]<60)
      {
        write_SegB();
        IsHaveCommand=0;
        raddr=0;
        _EINT();//�����ж� 
        strcpy(ATMSG,"AT+CIPSEND=13\r\n");//��������ָʾ
        senddata(ATMSG,strlen(ATMSG));
        //�ӳٵȴ����ȴ���Ϣ������
        Delay_ms(100);                             //�ӳ�100ms 
        
        ATMSG[0]=0xA5;     
        ATMSG[1]=0xA5;     
        ATMSG[2]=0x25;     
        ATMSG[3]=cd1.ID[0];     
        ATMSG[4]=cd1.ID[1]; 
        ATMSG[5]=cd1.ID[2];     
        ATMSG[6]=cd1.ID[3];     
        ATMSG[7]=0x01;     
        ATMSG[8]=0x01;     
        ATMSG[9]=0x55;     
        ATMSG[10]=0xFF;     
        ATMSG[11]=0x5A;     
        ATMSG[12]=0x5A;     
        senddata(ATMSG,13);
        
        cap_step = 1;
        //����GPS����
        UC1IE |= UCA1RXIE;
      }
      else//�趨��ʱ���С����
      {
        IsHaveCommand=0;
        raddr=0; 
        strcpy(ATMSG,"AT+CIPSEND=13\r\n");//��������ָʾ
        senddata(ATMSG,strlen(ATMSG));
        Delay_ms(100); 
        ATMSG[0]=0xA5;
        ATMSG[1]=0xA5; 
        ATMSG[2]=0x25; 
        ATMSG[3]=cd1.ID[0];     
        ATMSG[4]=cd1.ID[1]; 
        ATMSG[5]=cd1.ID[2];     
        ATMSG[6]=cd1.ID[3];     
        ATMSG[7]=0x01;     
        ATMSG[8]=0x01;         
        ATMSG[9]=0xAA;
        ATMSG[10]=0xFF;
        ATMSG[11]=0x5A;
        ATMSG[12]=0x5A;
        senddata(ATMSG,13);
        Delay_ms(100);
        
        CCTL0 |= CCIE;                       // CCR0 interrupt enabled
        CCR0 = 0x3BFE;
        TACTL = TASSEL_1 + MC_1 + ID_3;      // ACLK/8=512Hz, upmode 
       
        IE2 |= UCA0RXIE;                     //����������������   
      }
     }
     break;
     
   case 0x26:
     if(temp[7]==0x0)                       //�ж��Ƿ�Ϊ��ȡ����
     {
       IsHaveCommand=0;
       raddr=0; 
       strcpy(ATMSG,"AT+CIPSEND=16\r\n");   //��������ָʾ
       senddata(ATMSG,strlen(ATMSG));
       //�ӳ�100ms
       Delay_ms(100);

      ATMSG[0]  = 0xA5;
      ATMSG[1]  = 0xA5;    
      ATMSG[2]  = 0x26;    
      ATMSG[3]  = cd1.ID[0];     
      ATMSG[4]  = cd1.ID[1]; 
      ATMSG[5]  = cd1.ID[2];     
      ATMSG[6]  = cd1.ID[3];     
      ATMSG[7]  = 0x00;     
      ATMSG[8]  = 0x04;     
      ATMSG[9]  = wak_clo.T_Open >> 8;     
      ATMSG[10] = wak_clo.T_Open & 0xFF;
      ATMSG[11] = wak_clo.T_Close >> 8;     
      ATMSG[12] = wak_clo.T_Close & 0xFF;
      ATMSG[13] = 0xFF;
      ATMSG[14] = 0x5A;
      ATMSG[15] = 0x5A;
      senddata(ATMSG,16);
      //�ӳ�100ms
      Delay_ms(100);
      
      CCTL0 |= CCIE;                       // CCR0 interrupt enabled
      CCR0 = 0x3BFE;
      TACTL = TASSEL_1 + MC_1 + ID_3;      // ACLK/8=512Hz, upmode 
       
      IE2 |= UCA0RXIE;                     //���������������� 
     }
     else{
       //�޸Ŀ���ʱ����
       wak_clo.T_Open   = temp[9] << 8;
       wak_clo.T_Open  += temp[10];
       wak_clo.T_Close  = temp[11] << 8;
       wak_clo.T_Close += temp[12];
       
       if( wak_clo.T_Close == 0) wak_clo.T_Close = 1;
       
      //������ʱ���ر�ʱ������������flash��D����(ox10000) 
      write_SegD();    
      
      IsHaveCommand=0;
      raddr=0; 
      strcpy(ATMSG,"AT+CIPSEND=16\r\n");   //��������ָʾ
      senddata(ATMSG,strlen(ATMSG));
      
      //�ӳ�100ms
      Delay_ms(100);

      ATMSG[0]  =0xA5;
      ATMSG[1]  =0xA5;    
      ATMSG[2]  =0x26;    
      ATMSG[3]  =cd1.ID[0];     
      ATMSG[4]  =cd1.ID[1]; 
      ATMSG[5]  =cd1.ID[2];     
      ATMSG[6]  =cd1.ID[3];     
      ATMSG[7]  =0x01;     
      ATMSG[8]  =0x04;     
      ATMSG[9]  = wak_clo.T_Open >> 8 ;     
      ATMSG[10] = wak_clo.T_Open & 0xFF ; 
      ATMSG[11] = wak_clo.T_Close >> 8;     
      ATMSG[12] = wak_clo.T_Close & 0xFF;
      ATMSG[13] =0xFF;
      ATMSG[14] =0x5A;
      ATMSG[15] =0x5A;
      senddata(ATMSG,16);
      //�ӳ�100ms
      Delay_ms(100);
      
      CCTL0 |= CCIE;                       // CCR0 interrupt enabled
      CCR0 = 0x3BFE;
      TACTL = TASSEL_1 + MC_1 + ID_3;      // ACLK/8=512Hz, upmode 
       
      IE2 |= UCA0RXIE;                     //����������������  
     }
     break;
     
   //��ȡ�豸�ľ�γ�� 
   case 0x27:
       IsHaveCommand=0;
       raddr=0; 
       strcpy(ATMSG,"AT+CIPSEND=35\r\n");//��������ָʾ
       senddata(ATMSG,strlen(ATMSG));
       //�ӳ�100ms
       Delay_ms(100);

      ATMSG[0]=0xA5;
      ATMSG[1]=0xA5;    
      ATMSG[2]=0x27;    
      ATMSG[3]=cd1.ID[0];     
      ATMSG[4]=cd1.ID[1]; 
      ATMSG[5]=cd1.ID[2];     
      ATMSG[6]=cd1.ID[3];     
      ATMSG[7]=0x00;     
      ATMSG[8]=0x16;
      ATMSG[9]='N';
      ATMSG[10]= Lngtude_Lattude.Lat[0];
      ATMSG[11]= Lngtude_Lattude.Lat[1];
      ATMSG[12]= Lngtude_Lattude.Lat[2];
      ATMSG[13]= Lngtude_Lattude.Lat[3];
      ATMSG[14]= Lngtude_Lattude.Lat[4];
      ATMSG[15]= Lngtude_Lattude.Lat[5];
      ATMSG[16]= Lngtude_Lattude.Lat[6];
      ATMSG[17]= Lngtude_Lattude.Lat[7];
      ATMSG[18]= Lngtude_Lattude.Lat[8];
      ATMSG[19]= Lngtude_Lattude.Lat[9];
      ATMSG[20]='E';
      ATMSG[21]= Lngtude_Lattude.Lng[0];
      ATMSG[22]= Lngtude_Lattude.Lng[1];
      ATMSG[23]= Lngtude_Lattude.Lng[2];
      ATMSG[24]= Lngtude_Lattude.Lng[3];
      ATMSG[25]= Lngtude_Lattude.Lng[4];
      ATMSG[26]= Lngtude_Lattude.Lng[5];
      ATMSG[27]= Lngtude_Lattude.Lng[6];
      ATMSG[28]= Lngtude_Lattude.Lng[7];
      ATMSG[29]= Lngtude_Lattude.Lng[8];
      ATMSG[30]= Lngtude_Lattude.Lng[9];
      ATMSG[31]= Lngtude_Lattude.Lng[10];     
      ATMSG[32]=0xFF;
      ATMSG[33]=0x5A;
      ATMSG[34]=0x5A;
      senddata(ATMSG,35);
      //�ӳ�100ms
      Delay_ms(100);
      
      CCTL0 |= CCIE;                       // CCR0 interrupt enabled
      CCR0 = 0x3BFE;
      TACTL = TASSEL_1 + MC_1 + ID_3;      // ACLK/8=512Hz, upmode 
       
      IE2 |= UCA0RXIE;                     //���������������� 
     break;
   
     case 0x28:
     if(temp[7]==0x0)
     {
      strcpy(ATMSG,"AT+CIPSEND=13\r\n");   //��������ָʾ
      senddata(ATMSG,strlen(ATMSG));
      
      //�ӳ�100ms
      Delay_ms(100);
      
      ATMSG[0]  = 0xA5;
      ATMSG[1]  = 0xA5;    
      ATMSG[2]  = 0x28;    
      ATMSG[3]  = cd1.ID[0];     
      ATMSG[4]  = cd1.ID[1]; 
      ATMSG[5]  = cd1.ID[2];     
      ATMSG[6]  = cd1.ID[3];     
      ATMSG[7]  = 0x00;     
      ATMSG[8]  = 0x01;     
      ATMSG[9]  = off_set.offset;         
      ATMSG[10] = 0xFF;
      ATMSG[11] = 0x5A;
      ATMSG[12] = 0x5A;
      senddata(ATMSG,13);
     }
     else{
      off_set.offset = temp[9];
      strcpy(ATMSG,"AT+CIPSEND=13\r\n");   //��������ָʾ
      senddata(ATMSG,strlen(ATMSG));
      
      write_SegD();                        //�洢ƫ�Ʋ���
      //�ӳ�100ms
      Delay_ms(100);
      
      ATMSG[0]  = 0xA5;
      ATMSG[1]  = 0xA5;    
      ATMSG[2]  = 0x28;    
      ATMSG[3]  = cd1.ID[0];     
      ATMSG[4]  = cd1.ID[1]; 
      ATMSG[5]  = cd1.ID[2];     
      ATMSG[6]  = cd1.ID[3];     
      ATMSG[7]  = 0x01;     
      ATMSG[8]  = 0x01;     
      ATMSG[9]  = 0x55;         
      ATMSG[10] = 0xFF;
      ATMSG[11] = 0x5A;
      ATMSG[12] = 0x5A;
      senddata(ATMSG,13); 
     }
    CCTL0 |= CCIE;                       //CCR0 interrupt enabled
    CCR0 = 0x3BFE;
    TACTL = TASSEL_1 + MC_1 + ID_3;      //ACLK/8=512Hz, upmode 
       
    IE2 |= UCA0RXIE;                     //����������������  
       break;
       
   case 0x29:
     if(temp[7]==0x0){
       strcpy(ATMSG,"AT+CIPSEND=29\r\n");   //��������ָʾ
       senddata(ATMSG,strlen(ATMSG));
       //�ӳ�100ms
       Delay_ms(100);
       ATMSG[0]  = 0xA5;
       ATMSG[1]  = 0xA5;    
       ATMSG[2]  = 0x29;    
       ATMSG[3]  = cd1.ID[0];     
       ATMSG[4]  = cd1.ID[1]; 
       ATMSG[5]  = cd1.ID[2];     
       ATMSG[6]  = cd1.ID[3];     
       ATMSG[7]  = 0x00;     
       ATMSG[8]  = 0x10;
       for(char sum = 0;sum < 16; sum++){
         ATMSG[sum+9] = wd1.ServerIP[sum];
       }     
       ATMSG[25] = 0x55;         
       ATMSG[26] = 0xFF;
       ATMSG[27] = 0x5A;
       ATMSG[28] = 0x5A;
       senddata(ATMSG,29);
     }
     else{
       //���ṹ���е�IP�޸�
       for( sum = 9; temp[sum] != 0 ;sum++)
         wd1.ServerIP[sum-9] = temp[sum];
       
       wd1.ServerIP[sum-9] = 0;  
       
       write_SegC();                      //�Ѳ����洢����
         strcpy(ATMSG,"AT+CIPSEND=13\r\n");   //��������ָʾ
       senddata(ATMSG,strlen(ATMSG));
       
       //�ӳ�100ms
       Delay_ms(100);
       
       ATMSG[0]  = 0xA5;
       ATMSG[1]  = 0xA5;    
       ATMSG[2]  = 0x29;    
       ATMSG[3]  = cd1.ID[0];     
       ATMSG[4]  = cd1.ID[1]; 
       ATMSG[5]  = cd1.ID[2];     
       ATMSG[6]  = cd1.ID[3];     
       ATMSG[7]  = 0x00;     
       ATMSG[8]  = 0x01;     
       ATMSG[9]  = 0x55;         
       ATMSG[10] = 0xFF;
       ATMSG[11] = 0x5A;
       ATMSG[12] = 0x5A;
       senddata(ATMSG,13);
     }
      CCTL0 |= CCIE;                       // CCR0 interrupt enabled
      CCR0 = 0x3BFE;
      TACTL = TASSEL_1 + MC_1 + ID_3;      // ACLK/8=512Hz, upmode 
       
      IE2 |= UCA0RXIE;                     //���������������� 
     break;
         
       case 0x30:
       	 if(temp[7]==0x0){
         strcpy(ATMSG,"AT+CIPSEND=20\r\n");   //��������ָʾ
         senddata(ATMSG,strlen(ATMSG));
         //�ӳ�100ms
         Delay_ms(100);
         
         ATMSG[0]  = 0xA5;
         ATMSG[1]  = 0xA5;    
         ATMSG[2]  = 0x29;    
         ATMSG[3]  = cd1.ID[0];     
         ATMSG[4]  = cd1.ID[1]; 
         ATMSG[5]  = cd1.ID[2];     
         ATMSG[6]  = cd1.ID[3];     
         ATMSG[7]  = 0x00;     
         ATMSG[8]  = 0x10;
         for(char sum = 0;sum < 8; sum++)
         {
         	ATMSG[sum+9] = wd1.Serverport[sum];
         }     
         ATMSG[16] = 0x55;         
         ATMSG[17] = 0xFF;
         ATMSG[18] = 0x5A;
         ATMSG[19] = 0x5A;
         senddata(ATMSG,20);
       	}
       	else{
       		
         for( sum = 9; temp[sum] != 0 ;sum++)
          wd1.Serverport[sum-9] = temp[sum];
          
         wd1.Serverport[sum-9] = 0; 
           write_SegC();                      //�Ѳ����洢����   
               
         strcpy(ATMSG,"AT+CIPSEND=13\r\n");   //��������ָʾ
         senddata(ATMSG,strlen(ATMSG));
      
         //�ӳ�100ms
         Delay_ms(100);
      
         ATMSG[0]  = 0xA5;
         ATMSG[1]  = 0xA5;    
         ATMSG[2]  = 0x30;    
         ATMSG[3]  = cd1.ID[0];     
         ATMSG[4]  = cd1.ID[1]; 
         ATMSG[5]  = cd1.ID[2];     
         ATMSG[6]  = cd1.ID[3];     
         ATMSG[7]  = 0x00;     
         ATMSG[8]  = 0x01;     
         ATMSG[9]  = 0x55;         
         ATMSG[10] = 0xFF;
         ATMSG[11] = 0x5A;
         ATMSG[12] = 0x5A;
         senddata(ATMSG,13);
       }
      CCTL0 |= CCIE;                       // CCR0 interrupt enabled
      CCR0 = 0x3BFE;
      TACTL = TASSEL_1 + MC_1 + ID_3;      // ACLK/8=512Hz, upmode 
       
      IE2 |= UCA0RXIE;                     //���������������� 
         break;
       case 0x31:
       	 if(temp[7]==0x0){
         strcpy(ATMSG,"AT+CIPSEND=27\r\n");   //��������ָʾ
         senddata(ATMSG,strlen(ATMSG));
         //�ӳ�100ms
         Delay_ms(100);
         
         ATMSG[0]  = 0xA5;
         ATMSG[1]  = 0xA5;    
         ATMSG[2]  = 0x29;    
         ATMSG[3]  = cd1.ID[0];     
         ATMSG[4]  = cd1.ID[1]; 
         ATMSG[5]  = cd1.ID[2];     
         ATMSG[6]  = cd1.ID[3];     
         ATMSG[7]  = 0x00;     
         ATMSG[8]  = 0x10;
         for(char sum = 0;sum < 15; sum++)
         {
         	ATMSG[sum+9] = wd1.Ap_name[sum];
         }     
         ATMSG[23] = 0x55;         
         ATMSG[24] = 0xFF;
         ATMSG[25] = 0x5A;
         ATMSG[26] = 0x5A;
         senddata(ATMSG,27);
       	}
       	else{
       		
         for( sum = 9; temp[sum] != 0 ;sum++)
          wd1.Ap_name[sum-9] = temp[sum];
          
         wd1.Ap_name[sum-9] = 0; 
         write_SegC();                      //�Ѳ����洢����   
               
         strcpy(ATMSG,"AT+CIPSEND=13\r\n");   //��������ָʾ
         senddata(ATMSG,strlen(ATMSG));
      
         //�ӳ�100ms
         Delay_ms(100);
      
         ATMSG[0]  = 0xA5;
         ATMSG[1]  = 0xA5;    
         ATMSG[2]  = 0x30;    
         ATMSG[3]  = cd1.ID[0];     
         ATMSG[4]  = cd1.ID[1]; 
         ATMSG[5]  = cd1.ID[2];     
         ATMSG[6]  = cd1.ID[3];     
         ATMSG[7]  = 0x00;     
         ATMSG[8]  = 0x01;     
         ATMSG[9]  = 0x55;         
         ATMSG[10] = 0xFF;
         ATMSG[11] = 0x5A;
         ATMSG[12] = 0x5A;
         senddata(ATMSG,13);
       }
      CCTL0 |= CCIE;                       // CCR0 interrupt enabled
      CCR0 = 0x3BFE;
      TACTL = TASSEL_1 + MC_1 + ID_3;      // ACLK/8=512Hz, upmode 
       
      IE2 |= UCA0RXIE;                     //���������������� 
       break;
         
       case 0x32:
       	 if(temp[7]==0x0){
         strcpy(ATMSG,"AT+CIPSEND=24\r\n");   //��������ָʾ
         senddata(ATMSG,strlen(ATMSG));
         //�ӳ�100ms
         Delay_ms(100);
         
         ATMSG[0]  = 0xA5;
         ATMSG[1]  = 0xA5;    
         ATMSG[2]  = 0x29;    
         ATMSG[3]  = cd1.ID[0];     
         ATMSG[4]  = cd1.ID[1]; 
         ATMSG[5]  = cd1.ID[2];     
         ATMSG[6]  = cd1.ID[3];     
         ATMSG[7]  = 0x00;     
         ATMSG[8]  = 0x10;
         for(char sum = 0;sum < 12; sum++){
         	ATMSG[sum+9] = wd1.AP_password[sum];
         }     
         ATMSG[20] = 0x55;         
         ATMSG[21] = 0xFF;
         ATMSG[22] = 0x5A;
         ATMSG[23] = 0x5A;
         senddata(ATMSG,24);
       	}
       	else{
         for( sum = 9; temp[sum] != 0 ;sum++)
          wd1.AP_password[sum-9] = temp[sum];
          
         wd1.AP_password[sum-9] = 0; 
         write_SegC();                   //�Ѳ����洢����   
               
         strcpy(ATMSG,"AT+CIPSEND=13\r\n");   //��������ָʾ
         senddata(ATMSG,strlen(ATMSG));
      
         //�ӳ�100ms
         Delay_ms(100);
      
         ATMSG[0]  = 0xA5;
         ATMSG[1]  = 0xA5;    
         ATMSG[2]  = 0x30;    
         ATMSG[3]  = cd1.ID[0];     
         ATMSG[4]  = cd1.ID[1]; 
         ATMSG[5]  = cd1.ID[2];     
         ATMSG[6]  = cd1.ID[3];     
         ATMSG[7]  = 0x00;     
         ATMSG[8]  = 0x01;     
         ATMSG[9]  = 0x55;         
         ATMSG[10] = 0xFF;
         ATMSG[11] = 0x5A;
         ATMSG[12] = 0x5A;
         senddata(ATMSG,13);
       }
      CCTL0 |= CCIE;                       // CCR0 interrupt enabled
      CCR0 = 0x3BFE;
      TACTL = TASSEL_1 + MC_1 + ID_3;      // ACLK/8=512Hz, upmode 
       
      IE2 |= UCA0RXIE;                     //���������������� 
       break;
     
    default:
    CCTL0 |= CCIE;                       //CCR0 interrupt enabled
    CCR0 = 0x3BFE;
    TACTL = TASSEL_1 + MC_1 + ID_3;      //ACLK/8=512Hz, upmode 
       
    IE2 |= UCA0RXIE;                     //����������������    
      break; 
   }//switch(temp[2]) //������� 
}

