#include "wizepipes.h"
extern  char temp[MAX_BUFFER];
extern WDATA wd1;
extern CDATA cd1;
extern TDATA td1;
extern WAk_CLO wak_clo;

void write_SegB()
{
  char *Flash_ptr;                          // Flash pointer
  unsigned int i;

  Flash_ptr = (char *)0x1080;               // Initialize Flash pointer
  FCTL3 = FWKEY;                            // Clear Lock bit
  FCTL1 = FWKEY + ERASE;                    // Set Erase bit
 *Flash_ptr = 0;                           // Dummy write to erase Flash seg

  FCTL1 = FWKEY + WRT;                      // Set WRT bit for write operation
  
    for (i = 9; i<13; i++)
    {
      *Flash_ptr++ = temp[i];                   // Write value to flash
    }
  
    FCTL1 = FWKEY;                            // Clear WRT bit
    FCTL3 = FWKEY + LOCK;                     // Set LOCK bit
  
    Flash_ptr = (char *)0x1080;               // Initialize Flash pointer
  
    td1.hour = *Flash_ptr++;                  //������ʱ��д��ṹ����
    td1.minute = *Flash_ptr++;
    td1.seconds = *Flash_ptr++;
    td1.ms = *Flash_ptr++;
    
}
/****�洢ƫ��WiFi����**********/
/*
Input:     ��
Output:    �� 
*/
void write_SegC()
{
  char *Flash_ptr;                          // Flash pointer
  char i;
  
  Flash_ptr = (char *)0x1040;               // Initialize Flash pointer
  FCTL3 = FWKEY;                            // Clear Lock bit
  FCTL1 = FWKEY + ERASE;                    // Set Erase bit
 *Flash_ptr = 0;                           // Dummy write to erase Flash seg

  FCTL1 = FWKEY + WRT;                      // Set WRT bit for write operation
  
  for(i=0;i<15;i++)*Flash_ptr++  = wd1.Ap_name[i];
  for(i=0;i<12;i++)*Flash_ptr++  = wd1.AP_password[i];
  for(i=0;i<16;i++)*Flash_ptr++  = wd1.ServerIP[i]; 
  for(i=0;i<8;i++)*Flash_ptr++   = wd1.Serverport[i] ;

  FCTL1 = FWKEY;                            // Clear WRT bit
  FCTL3 = FWKEY + LOCK;                     // Set LOCK bit

}

/*****************************
*name     : write_SegD
*function : �������ر�ʱ���������ڲ�flash��D��
*input    : ѡ������һ�ֹ���
*ouput    : 1�ɹ���0ʧ��
*****************************/
void write_SegD()
{ 
  char *Flash_ptr;                          // Flash pointer
  
  Flash_ptr = (char *)0x1000;               // Initialize Flash pointer
  FCTL3 = FWKEY;                            // Clear Lock bit
  FCTL1 = FWKEY + ERASE;                    // Set Erase bit
 *Flash_ptr = 0;                            // Dummy write to erase Flash seg

  FCTL1 = FWKEY + WRT;                      // Set WRT bit for write operation
  
   *Flash_ptr++ = wak_clo.T_Open>>4;
   *Flash_ptr++ = wak_clo.T_Open && 0xFF;
   *Flash_ptr++ = wak_clo.T_Close>>4;
   *Flash_ptr++ = wak_clo.T_Close && 0xFF;
   *Flash_ptr++ = 
   
    FCTL1 = FWKEY;                          // Clear WRT bit
    FCTL3 = FWKEY + LOCK;                   // Set LOCK bit
    
    Flash_ptr = (char *)0x1000;
   
    wak_clo.T_Open   = (*Flash_ptr)<<4;
    Flash_ptr++;
    wak_clo.T_Open  += *Flash_ptr++;
    wak_clo.T_Close  = (*Flash_ptr)<<4;
    Flash_ptr++;
    wak_clo.T_Close += *Flash_ptr++;
}

void MX29LV320t_Cmd_Erase_Chip()  
{  
  MX29LV320t_Command_Write(0xAAA, 0xAA);
  MX29LV320t_Command_Write(0x555, 0x55);  
  MX29LV320t_Command_Write(0xAAA, 0x80);
  MX29LV320t_Command_Write(0xAAA, 0xAA);  
  MX29LV320t_Command_Write(0x555, 0x55);
  MX29LV320t_Command_Write(0xAAA, 0x10);  
  Delay_ms(10000);//�ȴ�������
  Delay_ms(10000);//�ȴ�������
  Delay_ms(10000);//�ȴ�������
} 

void MX29LV320t_Flash_Write(unsigned long vaddress, unsigned char vdata)  
{  
 // int i;
  if(vaddress<0x400000)//flash �����ʿռ�Ϊ2M��16bits
  {
   
  MX29LV320t_Command_Write(0xAAA, 0xAA);
  MX29LV320t_Command_Write(0x555, 0x55);  
  MX29LV320t_Command_Write(0xAAA, 0xA0);
  MX29LV320t_Command_Write(vaddress, vdata);  
  //��ʱ�ȴ����Tds=45ns��CPUʱ������Ϊ1/CPU_CLK=83ns
 // for(i=0;i<0x0c;i++); 
  } 
} 

unsigned char MX29LV320t_Flash_Read(unsigned long vaddress)
{
  //int i;
  unsigned char tmp=0x0;
  
  if(vaddress<0x4000000)//flash �����ʿռ�Ϊ2M��16bits
  {
   P1DIR = 0x00;    
  //��ʼװ�ص�ַ
   P4OUT = (vaddress >> 1) & 0xFF; //��ȡA0-A07
   P5OUT = (vaddress >> 9) & 0xFF; //��ȡA08-A15 
   if(vaddress%2)P2OUT |= 0x20;
     else P2OUT &=~0x20;
   tmp = P2OUT & 0x60;
   tmp |= (vaddress >> 17) & 0x1F;//��ȡA16-A20��A-1
   P2OUT =tmp;  
  //ʹ��CEѡͨ�źţ��͵�ƽ��Ч
  P6OUT &= ~0x10;  
  //ʹ��OE����źţ��͵�ƽ��Ч
  P6OUT &= ~0x40;  
  //��ʱ�ȴ����Toe=35ns��CPUʱ������Ϊ1/CPU_CLK=83ns,��������ȴ�
  //for(i=0;i<100;i++);  
  //��ȡ����
  tmp = P1IN;  
  //CE OE�źŹض�
  P6OUT |= 0x50;  
  return tmp;  
  }
  else return 0x0FF;
}

void MX29LV320t_Cmd_Reset(void)
{
 int i=0;
 P6DIR |= 0x80;                             // P6.2 RESET#�źţ����0         
 P6OUT &= ~0x80;
 for(i=0;i<320;i++); //��ʱ500ns 
 P6OUT |= 0x80; // P6.7 RESET#�źţ����1  
 for(i=0;i<320;i++); //��ʱ20us
}

void MX29LV320t_Command_Write(unsigned long vaddress, unsigned char vdata)
{
  //int i;
  unsigned char tmp=0x0;
  
  if(vaddress<0x4000000)//flash �����ʿռ�Ϊ2M��16bits
  {
   P1DIR = 0xFF;    
  //��ʼװ�ص�ַ
   P4OUT = (vaddress >> 1) & 0xFF; //��ȡA0-A07
   P5OUT = (vaddress >> 9) & 0xFF; //��ȡA08-A15 
   if(vaddress%2)P2OUT |= 0x20;
     else P2OUT &=~0x20;
   tmp = P2OUT & 0x60;
   tmp |= (vaddress >> 17) & 0x1F;//��ȡA16-A20��A-1
   P2OUT =tmp;  
  //ʹ��CEѡͨ�źţ��͵�ƽ��Ч
  P6OUT &= ~0x10;  
    //װ������vdata
  P1OUT = vdata;  
  //ʹ��WE����źţ��͵�ƽ��Ч
  P6OUT &= ~0x20;  
  //��ʱ�ȴ����Toe=35ns��CPUʱ������Ϊ1/CPU_CLK=83ns,��������ȴ�
 // for(i=0;i<10;i++); 
  //WE�źŹض�
  P6OUT |= 0x20;  
  //CE�źŹض�
  P6OUT |= 0x10;
  }
}

void HY29LV320t_Cmd_Reset(void)
{
 
 int i=0;
 
// P1DIR |= 0x02;                          // P1.1 ΪCE#,���Ϊ1                                        
// P1OUT |= 0x02;  
 
// P1DIR |= 0x04;                          // P1.2 ΪOE#,���Ϊ1                                        
// P1OUT |= 0x04;  
 
 P6DIR |= 0x80;                             // P6.2 RESET#�źţ����0         
 P6OUT &= ~0x80;

 for(i=0;i<240;i++); //��ʱ500ns
 P6OUT |= 0x80; // P6.7 RESET#�źţ����1 
 
 for(i=0;i<240;i++); //��ʱ20us
}
