#include "msp430x24x.h"
#include "wizepipes.h"

#define CPU_CLK 16000000 //CPU����ʱ��Ϊ16M
#define DATA_QUANTITY (600000)
#define DATA_QUANTITY1 (600000)//(600000*5)//50000

/**********���ݽ���ȫ�ֱ���***********/
char rbuffer[MAX_BUFFER];
char raddr=0,IsHaveCommand=0;
char IsReceiveCommand=0;
/************************************/

/**********GPS���շ���ȫ�ֱ���***********/
char gpsrbuf[MAX_BUFFER];
char gpstbuf[MAX_BUFFER];
char isgpscmdok=0,gpsaddr=0,gpsstep=0;
/************************************/
/**********ATָ������***********/
char ATMSG[MAX_BUFFER];
/******************************/

/********1pps����ʱ�ı���*************/
PPS PPS1;
/**********************************/
/********�����뿪��ʱ��*************/
WAk_CLO wak_clo;
/**********************************/
char netstatus=0;//����״̬,Ĭ�϶Ͽ�

char ADdata[8];
unsigned char test_data;
unsigned long flash_addr=0x04;
char R_delay;
char temp[MAX_BUFFER];
unsigned char Iscontinue=0;
unsigned char counter=0;
unsigned char Isover =0;
unsigned char cap_step =0;
unsigned long time,time1; 
unsigned char hour=0,minute=0;
unsigned char time_hour=0;
unsigned char second=0;
unsigned short msecond =0;

unsigned char WDT_Func;
unsigned long timeout;
char gpstbuf[MAX_BUFFER];
Lng_Lat Lngtude_Lattude;
char GPS_stauts;
WDATA wd1;
CDATA cd1;
TDATA td1;

Task task;

void main( void )
{
  
  InitialSystem();                       //��ʼ��ϵͳ
  
  ReadConfig();                         //��ȡ���ò���
  timeout = 0;
  
  
  if(td1.hour<24 && td1.minute<60)
  {   
    cap_step = 1;   
    UC1IE |= UCA1RXIE;                  // ����GPS
    __bis_SR_register(GIE);     //�����жϣ��ȴ�����
    
    while(1)
    {
      if(task.checkWifiFlag)
      {
        if(CheckWifi())
          task.sendheartbeatFlag = 1;
        else task.ConnectwifiFlag =1;
        
        task.checkWifiFlag = 0;
      }
      else if(task.ConnectwifiFlag)
      {
        Connectwifi();
        
        task.ConnectwifiFlag = 0;
      }
      else if(task.sendheartbeatFlag)
      {
        sendheartbeat();
        
        task.sendheartbeatFlag = 0;
      }
      else if(task.dotaskFlag)
      {
        dotask();
        
        task.dotaskFlag = 0;
      }
      else if(task.parseGPSrbufFlag)
      {
        parseGPSrbuf();
        
        task.parseGPSrbufFlag = 0;
      }
      else if(task.EraseFlashFlag)
      {
        MX29LV320t_Cmd_Reset();                        //flash��оƬ��λ
        MX29LV320t_Cmd_Erase_Chip();                   //��flash����оƬ����
        
        task.EraseFlashFlag = 0;
      }
        
    }//end of while(1)
  }
  else                             
  {
    cap_step = 0; 
    IE2 |= UCA0RXIE;                   //����������������
  }  
  
}

//������粢����������
char CheckWifi()
{ 
  IsHaveCommand=0;
  raddr=0;
  strcpy(ATMSG,"AT+CIPSTATUS\r\n");  //��ѯIP״̬
  senddata(ATMSG,strlen(ATMSG));

  while(!IsHaveCommand && timeout!=1) _NOP();

  if(rbuffer[7]=='3')//2 get ip 3 builded 4 lost ip
  return 1;
  else return 0;
}

//����gps����
void parseGPSrbuf()
{
  unsigned char tmp1=0,tmp2=0;
  for(int i=7;i<13;i++)gpsrbuf[i] -=0x30;
  tmp1=0;
  tmp1 = gpsrbuf[7]*10 + gpsrbuf[8] + 8;
  if( (tmp1>=8) && (tmp1<=32) )
  {    
    if( tmp1>=24 )
      tmp1 -= 24;  
    
    tmp1 = (unsigned long)(tmp1*60);
    tmp1 = (unsigned long)(gpsrbuf[9]*10 + gpsrbuf[10]+tmp1);
    tmp2 = (unsigned long)(td1.hour*60+td1.minute);
    
    if(tmp2 < tmp1)  
      tmp1 = 24*60 - ( tmp1 - tmp2 );
    else
      tmp1 = tmp2 -tmp1;
    
    if( gpsrbuf[28] == 'N')
      for(char sum = 0;sum <10 ;sum++)
      {                     //����γ��
        Lngtude_Lattude.Lat[sum] = gpsrbuf[sum+17];
      }
    
    if( gpsrbuf[42] == 'E')
      for(char sum = 0;sum <11 ;sum++)
      {                     //���㾭��
        Lngtude_Lattude.Lng[sum] = gpsrbuf[sum+30];
      }
    
    switch(cap_step)
    {
    case 1:
      if(tmp1 == 3)                                          //����ɼ�ʱ��
      {
        cap_step = 3;
        IE2 &= ~UCA0RXIE;                        //������ͨѶ��׼���ɼ�����
        
        
        for(int i=0;i<8;i++)
          ADdata[i]=MX29LV320t_Flash_Read(i);
        if(ADdata[0]==0xFF&&ADdata[1]==0xFF&&ADdata[2]==0xFF&&ADdata[3]==0xFF&&ADdata[4]==0xFF&&ADdata[5]==0xFF&&ADdata[6]==0xFF&&ADdata[7]==0xFF)_NOP();
        else
        {
          MX29LV320t_Cmd_Reset();                        //flash��оƬ��λ
          MX29LV320t_Cmd_Erase_Chip();               //��flash����оƬ����
        }
        UC1IE |= UCA1RXIE;                       // Enable USCI_A1 RX interrupt 
      }
      else if( tmp1 > 3 )                        //�ɼ�ʱ��δ������ȴ�״̬
      {
        
        time=(unsigned long) (tmp1-3)*2;        //Ԥ��2���ӽ���ɼ���ȷ��ʱ״̬
        
        //��ʱʱ����Ϊ30��  
        CCTL0 |= CCIE;                         // CCR0 interrupt enabled
        CCR0 = 0x3BFE;
        TACTL = TASSEL_1 + MC_1 + ID_3;        // ACLK/8=512Hz, upmode  
        
        cap_step = 2;
        IE2 |= UCA0RXIE;                       //����������������
      } 
      else  
      {
        cap_step = 0;
        time = (unsigned long)(tmp1+1) * 2;
        
        //��ʱʱ����Ϊ30��  
        CCTL0 |= CCIE;                             
        CCR0   = 0x3BFE;
        TACTL  = TASSEL_1 + MC_1 + ID_3;            
        
        //���������������� 
        IE2 |= UCA0RXIE;     
        
      } 
      break;
      
    case 3:          
      time = (unsigned long)(tmp1*60-(gpsrbuf[11]*10 + gpsrbuf[12]));//�����������ʱ������   
      
      if(time == 0)
      {
        P2DIR &= ~0x80;
        P2IE |= 0x80;             // P2.7 interrupt enabled
        P2IES &= ~0x80;           // P2.7 lo/Hi edge
        P2IFG &= ~0x80;           // P2.7 IFG cleared
        
        PPS1.PPS_step = PPS_2;       
      }
      else 
        UC1IE |= UCA1RXIE;                          //����GPS����ȡ��ǰʱ��
      
      
      break;
      
    default: 
      break;
    }//end switch  
  }
  else
  {
    cap_step = 1;
    UC1IE   |= UCA1RXIE;                       //GPSʱ�䲻��ȷ���ȴ�GPSʱ����ȷ
  }
}

/*********************/
#pragma vector = WDT_VECTOR
__interrupt void watchdog_timer(void)
{
  timeout=1;
  IE1 &= ~WDTIE;
}


#pragma vector=PORT2_VECTOR
__interrupt void Port_2(void)
{  
  P2IFG &= ~0x80;                                  // P2.7 IFG cleared
  switch( PPS1.PPS_step )
  { 
  case PPS_1:
    PPS1.PPS1++;
    break;
    
  case PPS_2:
    //time--;                             
    //P2IFG &= ~0x80;         // P2.7 IFG cleared 
    
    //if(time == 0)
    //{
      P2IFG &= ~0x80;
      P2IE &= ~0x80;
      
      TBCCTL0 = CCIE;                           // CCR0 interrupt enabled
      TBCCR0  = 199;
      TBCTL   = TBSSEL_2 + MC_1 + ID_3;           // SMCLK/8 = 1MHz, upmode
      flash_addr = 0x0;
      
      //LPM1;             //enter LPM1
    //}
    break;
    
  case PPS_3:
    
    break;
    
  default:
    break;
    
  }
  timeout++;
}





