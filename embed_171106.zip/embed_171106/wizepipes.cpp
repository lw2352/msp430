#include "wizepipes.h"

/*

     
   //��ȡ�豸�ľ�γ�� 
   case 0x27:
       IsHaveCommand=0;
       raddr=0; 
       strcpy(ATMSG,"AT+CIPSEND=35\r\n");//��������ָʾ
       senddata(ATMSG,strlen(ATMSG));
       //�ӳ�100ms
       Delay_ms(100);

      ATMSG[0]=0xA5;
      ATMSG[1]=0xA5;    
      ATMSG[2]=0x27;    
      ATMSG[3]=cd1.ID[0];     
      ATMSG[4]=cd1.ID[1]; 
      ATMSG[5]=cd1.ID[2];     
      ATMSG[6]=cd1.ID[3];     
      ATMSG[7]=0x00;     
      ATMSG[8]=0x16;
      ATMSG[9]='N';
      ATMSG[10]= Lngtude_Lattude.Lat[0];
      ATMSG[11]= Lngtude_Lattude.Lat[1];
      ATMSG[12]= Lngtude_Lattude.Lat[2];
      ATMSG[13]= Lngtude_Lattude.Lat[3];
      ATMSG[14]= Lngtude_Lattude.Lat[4];
      ATMSG[15]= Lngtude_Lattude.Lat[5];
      ATMSG[16]= Lngtude_Lattude.Lat[6];
      ATMSG[17]= Lngtude_Lattude.Lat[7];
      ATMSG[18]= Lngtude_Lattude.Lat[8];
      ATMSG[19]= Lngtude_Lattude.Lat[9];
      ATMSG[20]='E';
      ATMSG[21]= Lngtude_Lattude.Lng[0];
      ATMSG[22]= Lngtude_Lattude.Lng[1];
      ATMSG[23]= Lngtude_Lattude.Lng[2];
      ATMSG[24]= Lngtude_Lattude.Lng[3];
      ATMSG[25]= Lngtude_Lattude.Lng[4];
      ATMSG[26]= Lngtude_Lattude.Lng[5];
      ATMSG[27]= Lngtude_Lattude.Lng[6];
      ATMSG[28]= Lngtude_Lattude.Lng[7];
      ATMSG[29]= Lngtude_Lattude.Lng[8];
      ATMSG[30]= Lngtude_Lattude.Lng[9];
      ATMSG[31]= Lngtude_Lattude.Lng[10];     
      ATMSG[32]=0xFF;
      ATMSG[33]=0x5A;
      ATMSG[34]=0x5A;
      senddata(ATMSG,35);
      //�ӳ�100ms
      Delay_ms(100);
      
      CCTL0 |= CCIE;                       // CCR0 interrupt enabled
      CCR0 = 0x3BFE;
      TACTL = TASSEL_1 + MC_1 + ID_3;      // ACLK/8=512Hz, upmode 
       
      IE2 |= UCA0RXIE;                     //���������������� 
     break;
   
     case 0x28:
     if(temp[7]==0x0)
     {
      strcpy(ATMSG,"AT+CIPSEND=13\r\n");   //��������ָʾ
      senddata(ATMSG,strlen(ATMSG));
      
      //�ӳ�100ms
      Delay_ms(100);
      
      ATMSG[0]  = 0xA5;
      ATMSG[1]  = 0xA5;    
      ATMSG[2]  = 0x28;    
      ATMSG[3]  = cd1.ID[0];     
      ATMSG[4]  = cd1.ID[1]; 
      ATMSG[5]  = cd1.ID[2];     
      ATMSG[6]  = cd1.ID[3];     
      ATMSG[7]  = 0x00;     
      ATMSG[8]  = 0x01;     
      ATMSG[9]  = off_set.offset;         
      ATMSG[10] = 0xFF;
      ATMSG[11] = 0x5A;
      ATMSG[12] = 0x5A;
      senddata(ATMSG,13);
     }
     else{
      off_set.offset = temp[9];
      strcpy(ATMSG,"AT+CIPSEND=13\r\n");   //��������ָʾ
      senddata(ATMSG,strlen(ATMSG));
      
      write_SegD();                        //�洢ƫ�Ʋ���
      //�ӳ�100ms
      Delay_ms(100);
      
      ATMSG[0]  = 0xA5;
      ATMSG[1]  = 0xA5;    
      ATMSG[2]  = 0x28;    
      ATMSG[3]  = cd1.ID[0];     
      ATMSG[4]  = cd1.ID[1]; 
      ATMSG[5]  = cd1.ID[2];     
      ATMSG[6]  = cd1.ID[3];     
      ATMSG[7]  = 0x01;     
      ATMSG[8]  = 0x01;     
      ATMSG[9]  = 0x55;         
      ATMSG[10] = 0xFF;
      ATMSG[11] = 0x5A;
      ATMSG[12] = 0x5A;
      senddata(ATMSG,13); 
     }
    CCTL0 |= CCIE;                       //CCR0 interrupt enabled
    CCR0 = 0x3BFE;
    TACTL = TASSEL_1 + MC_1 + ID_3;      //ACLK/8=512Hz, upmode 
       
    IE2 |= UCA0RXIE;                     //����������������  
       break;
       
    


         
    
     
    default:
    CCTL0 |= CCIE;                       //CCR0 interrupt enabled
    CCR0 = 0x3BFE;
    TACTL = TASSEL_1 + MC_1 + ID_3;      //ACLK/8=512Hz, upmode 
       
    IE2 |= UCA0RXIE;                     //����������������    
      break; 
   }//switch(temp[2]) //������� 
}

*/